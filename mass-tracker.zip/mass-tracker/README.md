# Mass Tracker

A comprehensive web application for Catholic priests to track Mass intentions.

